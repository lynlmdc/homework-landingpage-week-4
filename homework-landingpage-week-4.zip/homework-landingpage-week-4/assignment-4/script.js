

$(document).ready(function() {

$('.readmore a').click(readMore);
	function readMore(){
		event.preventDefault();
		$('#show-this-on-click').slideDown();
		$('.readmore').hide();
		$('.readless').show();
}

$('.readless a').click(readLess);
	function readLess(){
		event.preventDefault();
		$('#show-this-on-click').slideUp();
		$('.readless').hide();
		$('.readmore').show();
}
$('.learnmore').click(learnMore);
	function learnMore(){
		event.preventDefault();
		$('#learnmoretext').slideDown();
		$('.learnmore').hide();
}


//doc ready
});



